#!/bin/bash
# TriskeleToolchain Linux Setup Script
# Echopraxium with the collaboration of Claude AI
# Usage: bash setup_linux_env.sh <crates.zip> <Cargo.toml>
# Then: source ~/.cargo/env  (if needed)
set -e

echo "=== TriskeleToolchain Linux Environment Setup ==="

# 1. Install system deps
echo "[1/4] Installing system packages..."
apt-get install -y rustc cargo clang libsdl2-dev --fix-missing -qq 2>&1 | tail -3

# 2. Extract crates
CRATES_ZIP="${1:-crates.zip}"
echo "[2/4] Extracting crates from $CRATES_ZIP..."
unzip -q "$CRATES_ZIP" -d /home/claude/

# 3. Install workspace Cargo.toml
CARGO_TOML="${2:-Cargo.toml}"
echo "[3/4] Installing workspace Cargo.toml..."
cp "$CARGO_TOML" /home/claude/Cargo.toml

# 4. Pin clap to avoid edition2024 requirement (Cargo 1.75 limitation)
echo "[4/4] Pinning clap=4.4.18 for Cargo 1.75 compatibility..."
sed -i 's/clap.*=.*{ version = "4".*/clap       = { version = "=4.4.18", features = ["derive"] }/' /home/claude/Cargo.toml

# 5. Build
echo "[5/5] Building toolchain (this takes ~2 minutes)..."
cd /home/claude
cargo build -p tsk-cc -p tsk-link -p triskele-vm 2>&1 | grep -E "Compiling (tsk-cc|tsk-link|triskele-vm|triskele-common)|Finished|^error"

echo ""
echo "=== Setup complete! ==="
echo "Binaries at: /home/claude/target/debug/{tsk-cc,tsk-link,tskvm}"
echo ""
echo "Quick smoke test:"
mkdir -p /tmp/smoke
cat > /tmp/smoke/t.c << 'C_EOF'
int main() { return 31; }
C_EOF
clang -O0 -emit-llvm -S /tmp/smoke/t.c -o /tmp/smoke/t.ll
/home/claude/target/debug/tsk-cc /tmp/smoke/t.ll -o /tmp/smoke/t.tobj
/home/claude/target/debug/tsk-link /tmp/smoke/t.tobj -o /tmp/smoke/t.tvmx
EXIT=$(/home/claude/target/debug/tskvm /tmp/smoke/t.tvmx; echo $?)
echo "Smoke test exit: $EXIT (expected: 31)"
[ "$EXIT" = "31" ] && echo "✅ Pipeline OK" || echo "❌ FAILED"
