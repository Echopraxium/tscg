# TriskeleToolchain — Linux Debug Environment

## Pour démarrer une nouvelle session Claude (Linux sandbox)

Uploader ces 3 fichiers au début de la conversation :
1. `crates.zip` — sources des crates Rust
2. `Cargo.toml` — workspace manifest
3. `setup_linux_env.sh` — script d'installation

Puis dans le premier message dire :
> "Lance le setup Linux : bash /mnt/user-data/uploads/setup_linux_env.sh 
>  /mnt/user-data/uploads/crates.zip /mnt/user-data/uploads/Cargo.toml"

## Ce que ça installe
- rustc 1.75 + cargo (via apt)
- clang 18 (pour générer les .ll)
- libsdl2-dev
- Tous les crates du toolchain compilés en ~2 min

## Limitation connue
Cargo 1.75 (Ubuntu 24.04) ne supporte pas `edition2024`.
→ clap est automatiquement épinglé à 4.4.18.
→ Si ce workaround ne suffit plus, il faudra fournir un `Cargo.lock` précompilé.

## Binaires disponibles après setup
```
/home/claude/target/debug/tsk-cc    ← compilateur LLVM IR → .tobj
/home/claude/target/debug/tsk-link  ← linker .tobj → .tvmx
/home/claude/target/debug/tskvm     ← VM TriskeleVM
```

## Pipeline rapide (test manuel)
```bash
clang -O0 -emit-llvm -S foo.c -o foo.ll
/home/claude/target/debug/tsk-cc foo.ll -o foo.tobj
/home/claude/target/debug/tsk-link foo.tobj -o foo.tvmx
/home/claude/target/debug/tskvm foo.tvmx; echo "Exit: $?"
```
