# Patch v0.3.31 — fix stack pointer WASM (Memory fault addr=0x6FFFF...)

Le stack pointer était fixé à STACK_TOP=0x7000_0000 même en WASM
où la mémoire ne fait que 8 MB (max addr ~0x0081_1000).
Résultat : Memory fault dès le premier accès au stack.

Fix :
- load_tvmx() retourne maintenant (Memory, entry_pc, stack_top)
  où stack_top = STACK_TOP si ça rentre, sinon 3/4 de la mémoire allouée
- build_cpu_headless() prend stack_top en paramètre
- Cpu::new_with_stack() ajouté pour initialiser RegisterFile au bon SP
- triskele-vm-wasm utilise ces nouvelles signatures
