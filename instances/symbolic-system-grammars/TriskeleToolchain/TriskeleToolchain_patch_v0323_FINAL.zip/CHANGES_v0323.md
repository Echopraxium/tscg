# TriskeleToolchain — Patch v0.3.23
# Author: Echopraxium with the collaboration of Claude AI

## Scope
TODO-1 (Trampoline mechanism technical debt) — **Option A only**, per
Handover v0.3.22 §2 recommendation ("do this first"). Option B
(`Im_FarCall`/`L_FarCall`, removing trampolines entirely) is the next
step, not included in this patch.

## File changed
- `crates/tsk-link/src/main.rs`

## What changed

### 1. Phase 0 no longer unconditionally pre-populates LIBC_SYMBOLS
Previously, every name in `LIBC_SYMBOLS` got a far-stub address
(`0xE000_0000 + ...`) inserted into `global_syms` before any object's
own symbols were registered. If a linked object (e.g. `tsk-libc.tvml`,
linked as an ordinary object — see Handover §2 background) defined the
same name as real, in-range code, Phase 1's registration would
silently overwrite the stub address, logged only as
`WARNING: duplicate symbol @name`.

Phase 0b's trampoline pre-scan ran *before* that overwrite and counted
every such call as needing a trampoline; Phase 3 then resolved the
call against the real address and never emitted one — confirmed on
doom_wad as a 14-symbol / 336-byte divergence (43 pre-scanned vs 29
actual). Harmless in isolation (the data_base padding added in the
v0.3.20 B24 fix absorbs the gap), but it meant the pre-scan estimate
was never actually exact, just safely over-provisioned.

**Fix**: scan all linked objects' non-private code-symbol names first,
then only insert a `LIBC_SYMBOLS` stub address for names NOT in that
set. Resolution priority ("an object's own code wins over the fixed
libc stub") is now an explicit, checked rule instead of an accidental
side effect of HashMap insertion order. Phase 0b's pre-scan (which
runs immediately after) now sees the same address Phase 3 will
resolve against, so the trampoline count becomes exact — confirmed:
re-running the doom_wad-style repro case after this fix shows
`pre-scan: 0 libc relocs` and `n_trampolines=0` for calls to a
libc-name defined by a linked object, with **zero** `WARNING: duplicate
symbol` lines and **zero** `trampoline reservation mismatch` warnings.

### 2. `WARNING: duplicate symbol` promoted to a hard error for libc names
Since Phase 0's elimination logic above should make it impossible for
a `LIBC_SYMBOLS` name to ever reach Phase 1's "already in global_syms"
branch, reaching that branch for a libc name now means the elimination
itself has a bug (e.g. two *different* linked objects both define the
same libc-named symbol) — this is now `bail!`'d as an internal linker
error instead of silently logging a warning and proceeding, per the
explicit suggestion in Handover §2 ("if it does, that's now a genuine
bug signal worth promoting to a hard error"). Collisions between two
non-libc-named symbols are unaffected and still just warn.

### 3. Fixed a pre-existing broken test
`test_trampoline_reservation_counts_all_libc_relocs` was defined
*outside* the `mod tests { ... }` block (past its closing brace) and
hand-built a `.tobj` using a `"TOBJ"` magic that
`TvmFile::load_from_reader` never accepted (it requires `"TSKV"` —
`triskele_common::tvm::TVM_MAGIC`). This test has been failing on
every run prior to this patch, independent of anything trampoline- or
Option-A-related — confirmed by running the full `tsk-link` test suite
on the unmodified source before making any other change (7 passed, 1
failed, same failure). Fixed by rebuilding the same scenario with
`TvmBuilder`, consistent with every other test in the file, and
relocating it inside `mod tests`.

### 4. Three new tests added
- `test_object_defined_libc_name_skips_phase0_stub` — a libc-named
  symbol defined by a linked object must resolve to that object's
  in-range address, never the far stub.
- `test_object_defined_libc_name_produces_no_trampoline` — calls to
  such a symbol must produce zero trampolines and zero data_base
  padding (`data_base == code_base + code_len` exactly).
- `test_libc_name_without_object_definition_still_uses_trampoline` —
  regression guard for the opposite direction: when no object defines
  a given libc name, Phase 0 pre-population and the resulting
  trampoline must still happen exactly as before.

## Validation performed (Linux sandbox, Rust 1.75 + clang 18)
- `cargo build --workspace` (excl. `tsk-dbg`, not a workspace member) — clean.
- `cargo test -p tsk-link` — **11/11 pass** (was 7/8 before this patch;
  the 1 failure was the pre-existing broken test above, now fixed).
- `cargo test -p triskele-common -p tsk-cc` — unaffected, all pass
  (40 + 14 tests).
- Manual repro of the exact doom_wad bug shape: a `main.c` calling
  `printf` 3×, linked together with a `tsk-libc-gen`-generated
  `tsk-libc.tvml` (which defines `printf` as real code at an in-range
  address — same shape as the real `tsk-libc.tvml`/`LIBC_SYMBOLS`
  collision described in Handover §2):
  - **Before this patch**: `pre-scan: 3 libc relocs`, `n_trampolines=0`,
    `WARNING: duplicate symbol @printf` (+ 13 other duplicate-symbol
    warnings from the other overlapping names), `trampoline reservation
    mismatch: ... (diff=-72)`.
  - **After this patch**: `pre-scan: 0 libc relocs`, `n_trampolines=0`,
    zero warnings, zero mismatch. Resulting `.tvmx` is 72 bytes smaller
    (the previously-wasted padding).
  - Executed both the before/after binaries on `tskvm`: both exit 42
    with correct `printf` output (`abc`), confirming no behavioral
    regression — the fix changes bookkeeping accuracy, not runtime
    semantics.
- Did **not** have access to the `projects/Doom-Generic/` test corpus
  in this session, so `run_all_tests.py` (the 12-project regression
  suite) was not run here. **Please run it before/after this patch on
  the Windows checkout to confirm doom_wad's WARNING lines disappear
  and all 12 projects stay green** — the repro above is a minimal
  stand-in for that scenario, not a substitute for the real corpus.

## Not in scope for this patch
- Option B (`Im_FarCall` / direct in-place far call, removing the
  trampoline mechanism entirely) — next, per the agreed priority order.
- Option C (trampoline deduplication) — deprioritized per Handover §2
  recommendation; revisit only if B is deferred long-term.
- `tsk-libc-gen`'s `LIBC_FUNCTIONS` vs `triskele-vm`'s `ALL_SYSCALLS`
  vs `triskele-common`'s `LIBC_SYMBOLS` three-way table sync (the M2
  "libc parity" item) — out of scope for the trampoline fix itself;
  noted in passing that `LIBC_SYMBOLS` (54 entries) and `ALL_SYSCALLS`
  (53 entries) appear already close to parity in this codebase
  snapshot, while `tsk-libc-gen`'s `LIBC_FUNCTIONS` (24 entries) is the
  one with a real, partial (14-name) overlap against both — worth a
  quick look in a future session but didn't block this fix.
