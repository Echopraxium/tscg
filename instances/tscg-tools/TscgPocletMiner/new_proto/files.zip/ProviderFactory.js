'use strict';

const { OllamaProvider    } = require('./OllamaProvider');
const { DeepSeekProvider  } = require('./DeepSeekProvider');
const { AnthropicProvider } = require('./AnthropicProvider');

/**
 * ProviderFactory — Creates LLMProvider instances from a config object.
 *
 * Config example (stored in Electron app userData as llm_config.json):
 * {
 *   "active": "ollama",
 *   "providers": {
 *     "ollama":    { "model": "phi3.5:3.8b-mini-instruct-q4_K_M" },
 *     "deepseek":  { "apiKey": "sk-..." },
 *     "anthropic": { "apiKey": "sk-ant-...", "model": "claude-haiku-4-5-20251001" }
 *   }
 * }
 *
 * Author: Echopraxium with the collaboration of Claude AI
 */

// Registry of available backends
const REGISTRY = {
  ollama:    OllamaProvider,
  deepseek:  DeepSeekProvider,
  anthropic: AnthropicProvider,
};

// Human-readable descriptions for the UI selector
const PROVIDER_META = {
  ollama: {
    label:       'Local — Ollama',
    description: 'LLM local gratuit (Phi-3.5 Mini 3.8B recommandé pour 4 GB VRAM)',
    icon:        '🏠',
    requiresKey: false,
    quality:     '⭐⭐⭐',
    speed:       '~25 tok/s',
  },
  deepseek: {
    label:       'Cloud — DeepSeek API',
    description: 'Paiement à l\'usage, format OpenAI-compatible, très économique',
    icon:        '☁️',
    requiresKey: true,
    quality:     '⭐⭐⭐⭐⭐',
    speed:       'rapide',
  },
  anthropic: {
    label:       'Cloud — Claude API (Anthropic)',
    description: 'Haiku (rapide/économique) ou Sonnet (qualité max)',
    icon:        '⭐',
    requiresKey: true,
    quality:     '⭐⭐⭐⭐⭐',
    speed:       'rapide',
  },
};

class ProviderFactory {
  /**
   * Create the active provider from a full config object.
   * @param {object} config  Full config as described above
   * @returns {LLMProvider}
   */
  static create(config) {
    const id = config.active;
    if (!id) throw new Error('ProviderFactory: config.active is missing');

    const Cls = REGISTRY[id];
    if (!Cls) throw new Error(`ProviderFactory: unknown provider "${id}". Valid: ${Object.keys(REGISTRY).join(', ')}`);

    const providerConfig = config.providers?.[id] ?? {};
    return new Cls(providerConfig);
  }

  /**
   * Return metadata for all registered providers (for UI rendering).
   * @returns {object[]}
   */
  static listProviders() {
    return Object.entries(PROVIDER_META).map(([id, meta]) => ({ id, ...meta }));
  }

  /**
   * Check availability of ALL configured providers.
   * Useful for the settings panel "Test connection" button.
   *
   * @param {object} config  Full config
   * @returns {Promise<object>}  { providerId: { ok, message } }
   */
  static async checkAll(config) {
    const results = {};
    for (const [id, Cls] of Object.entries(REGISTRY)) {
      const providerConfig = config.providers?.[id];
      if (!providerConfig) {
        results[id] = { ok: false, message: 'Not configured' };
        continue;
      }
      try {
        const provider = new Cls(providerConfig);
        results[id] = await provider.isAvailable();
      } catch (err) {
        results[id] = { ok: false, message: err.message };
      }
    }
    return results;
  }

  /**
   * Default config — safe starting point for new installations.
   * @returns {object}
   */
  static defaultConfig() {
    return {
      active: 'ollama',
      providers: {
        ollama:    { model: 'phi3.5:3.8b-mini-instruct-q4_K_M' },
        deepseek:  { apiKey: '', model: 'deepseek-chat' },
        anthropic: { apiKey: '', model: 'claude-haiku-4-5-20251001' },
      },
    };
  }
}

module.exports = { ProviderFactory, PROVIDER_META };
