'use strict';

const fs   = require('fs');
const path = require('path');
const { TfIdfRetriever } = require('./TfIdfRetriever');

/**
 * RagBuilder — On-the-fly RAG from the local TSCG ontology files.
 *
 * Replaces the pre-built ChromaDB corpus (no longer in GitHub deliverables).
 * Scans the user's local TSCG repo, parses JSON-LD files, extracts text
 * chunks, and builds an in-memory TF-IDF index at startup.
 *
 * Sources indexed (in priority order):
 *   1. M2_GenericConcepts.jsonld   — 75 atomic GenericConcepts
 *   2. M1_CoreConcepts.jsonld      — Combos and KnowledgeFieldConceptCombos
 *   3. M1_extensions/**            — Domain extensions (Biology, Chemistry…)
 *   4. instances/poclets/**        — M0_*.jsonld poclets
 *
 * Author: Echopraxium with the collaboration of Claude AI
 */

// Relative paths inside the TSCG repo root
const SCAN_TARGETS = [
  { rel: 'ontology/M2_GenericConcepts.jsonld', priority: 'high'   },
  { rel: 'ontology/M1_CoreConcepts.jsonld',    priority: 'high'   },
  { rel: 'ontology/M1_extensions',             priority: 'medium', recursive: true },
  { rel: 'instances/poclets',                  priority: 'medium', recursive: true },
];

class RagBuilder {
  /**
   * @param {string} tscgRepoRoot  Absolute path to the local TSCG repo root
   *                               e.g. "E:\\_00_Michel\\_00_Lab\\_00_GitHub\\tscg"
   */
  constructor(tscgRepoRoot) {
    if (!tscgRepoRoot) throw new Error('RagBuilder: tscgRepoRoot is required');
    this._root      = tscgRepoRoot;
    this._retriever = new TfIdfRetriever();
    this._built     = false;
    this._stats     = { files: 0, chunks: 0, errors: 0 };
  }

  /**
   * Build the in-memory RAG index. Call once at app startup.
   * @param {function} [onProgress]  Optional callback(message: string)
   * @returns {Promise<object>}      Build stats { files, chunks, errors }
   */
  async build(onProgress = null) {
    const log = msg => { if (onProgress) onProgress(msg); };
    const chunks = [];

    log('RAG: scanning TSCG ontology files…');

    for (const target of SCAN_TARGETS) {
      const absPath = path.join(this._root, target.rel);
      if (!fs.existsSync(absPath)) {
        log(`RAG: skipping missing path: ${target.rel}`);
        continue;
      }

      const stat = fs.statSync(absPath);

      if (stat.isFile() && absPath.endsWith('.jsonld')) {
        this._processFile(absPath, target.priority, chunks);
      } else if (stat.isDirectory() && target.recursive) {
        this._scanDir(absPath, target.priority, chunks);
      }
    }

    log(`RAG: building TF-IDF index from ${chunks.length} chunks…`);
    this._retriever.addDocuments(chunks);
    this._stats.chunks = chunks.length;
    this._built = true;

    log(`RAG ready — ${this._stats.files} files, ${this._stats.chunks} chunks, ${this._stats.errors} errors`);
    return { ...this._stats };
  }

  /**
   * Retrieve the top-k most relevant chunks for a query.
   * Returns formatted context text ready to inject into a system prompt.
   *
   * @param {string} query
   * @param {number} [topK=6]
   * @returns {string}  Formatted context block
   */
  retrieve(query, topK = 6) {
    if (!this._built) return '';
    const results = this._retriever.search(query, topK);
    if (results.length === 0) return '';

    const lines = ['### TSCG Knowledge Context (RAG)\n'];
    for (const r of results) {
      lines.push(`**[${r.metadata.source ?? r.id}]** (score: ${r.score.toFixed(3)})`);
      lines.push(r.text.trim());
      lines.push('');
    }
    return lines.join('\n');
  }

  get isBuilt()  { return this._built; }
  get stats()    { return { ...this._stats }; }
  get docCount() { return this._retriever.size; }

  // ── private ────────────────────────────────────────────────────────────────

  _scanDir(dirPath, priority, chunks) {
    let entries;
    try { entries = fs.readdirSync(dirPath, { withFileTypes: true }); }
    catch { return; }

    for (const entry of entries) {
      if (entry.name.startsWith('_')) continue; // skip _archives, _protos etc.
      const full = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        this._scanDir(full, priority, chunks);
      } else if (entry.isFile() && entry.name.endsWith('.jsonld')) {
        this._processFile(full, priority, chunks);
      }
    }
  }

  _processFile(filePath, priority, chunks) {
    try {
      const raw  = fs.readFileSync(filePath, 'utf-8');
      const data = JSON.parse(raw);
      const fileChunks = this._extractChunks(data, filePath, priority);
      chunks.push(...fileChunks);
      this._stats.files++;
    } catch (err) {
      this._stats.errors++;
    }
  }

  /**
   * Extract text chunks from a parsed JSON-LD object.
   * Handles both single @graph items and array @graph.
   */
  _extractChunks(data, filePath, priority) {
    const fileName = path.basename(filePath);
    const chunks   = [];

    // Try @graph (M2, M1 files) or top-level array
    const items = data['@graph'] ?? (Array.isArray(data) ? data : [data]);

    for (const item of items) {
      if (!item || typeof item !== 'object') continue;

      const id    = this._str(item['@id'] ?? item['m2:id'] ?? '');
      const label = this._str(item['rdfs:label'] ?? item['skos:prefLabel'] ?? '');
      const comment = this._str(item['rdfs:comment'] ?? item['m2:comment'] ?? '');
      const family  = this._str(item['m2:family'] ?? '');
      const formula = this._str(item['m2:tensorFormula'] ?? item['m2:formula'] ?? '');
      const domains = this._str(item['m2:knowledgeField'] ?? item['m1:domain'] ?? '');
      const type    = this._str(item['@type'] ?? '');

      if (!label && !comment) continue; // skip structural-only nodes

      // Build a dense text representation for TF-IDF
      const parts = [label, type, family, formula, domains, comment]
        .filter(Boolean);

      // Add ASFID/REVOI scores as text if present
      const asfid = item['m0:asfidScore'];
      const revoi = item['m0:revoiScore'];
      if (asfid) parts.push(`ASFID: A=${asfid.A} S=${asfid.S} F=${asfid.F} I=${asfid.I} D=${asfid.D}`);
      if (revoi) parts.push(`REVOI: R=${revoi.R} E=${revoi.E} V=${revoi.V} O=${revoi.O} I=${revoi.I}`);

      chunks.push({
        id:   `${fileName}::${id || label}`,
        text: parts.join(' — '),
        metadata: {
          source:   fileName,
          label,
          type,
          family,
          formula,
          priority,
          filePath,
        },
      });
    }

    // If no @graph items found, treat the whole file as one chunk (README-style)
    if (chunks.length === 0) {
      const text = this._flattenObject(data);
      if (text.length > 20) {
        chunks.push({
          id:       fileName,
          text,
          metadata: { source: fileName, priority },
        });
      }
    }

    return chunks;
  }

  _str(v) {
    if (!v) return '';
    if (typeof v === 'string') return v;
    if (typeof v === 'object') return v['@value'] ?? v['rdfs:label'] ?? JSON.stringify(v);
    return String(v);
  }

  _flattenObject(obj, depth = 0) {
    if (depth > 3) return '';
    if (typeof obj === 'string') return obj;
    if (Array.isArray(obj)) return obj.map(v => this._flattenObject(v, depth + 1)).join(' ');
    if (typeof obj === 'object' && obj !== null) {
      return Object.values(obj).map(v => this._flattenObject(v, depth + 1)).join(' ');
    }
    return String(obj);
  }
}

module.exports = { RagBuilder };
